package com.wcs.coursjava.entity;

public interface Attaque {

    public void attaque1();
    public void attaque2();
    public void attaque3();
    public void attaque4();
}
