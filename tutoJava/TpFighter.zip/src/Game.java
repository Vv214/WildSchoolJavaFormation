import entity.Guerrier;
import entity.Mage;
import entity.Player;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game {

    private Player p1;
    private Player p2;

    private Scanner sc;

    public Game() {
        sc = new Scanner(System.in);
    }

    public void run() {
        selectPlayers();
        var winner = fight();
        gameOver(winner);
        sc.close();
    }

    private void selectPlayers() {
        System.out.println("=== JOUEUR 1 ===");
        p1 = selectPlayer();
        System.out.println("=== JOUEUR 2 ===");
        p2 = selectPlayer();

        p1.setEnnemie(p2);
        p2.setEnnemie(p1);
    }

    private void gameOver(boolean tour) {
        var winner = tour ? p1.getName() : p2.getName();
        System.out.println(winner + " a gagné !!! \n\n" +
                "=== GAME OVER ===");
    }

    private Player selectPlayer(boolean alreadyCall) {
        Player player;
        if (!alreadyCall) {
            System.out.print("Choix perso : 1) Guerrier 2) Mage\n" +
                    "-> ");
        }
        try {
            var select = sc.nextInt();
            if (select == 1) {
                player = new Guerrier();
            } else if (select == 2) {
                player = new Mage();
            } else {
                System.out.println("Recommence : saisir 1 ou 2");
                return selectPlayer(true);
            }
            return player;
        } catch (Exception e) {
            System.out.println("Recommence : saisir 1 ou 2");
            sc = new Scanner(System.in);
            return selectPlayer(true);
        }
    }

    private Player selectPlayer() {
        return selectPlayer(false);
    }

    private boolean fight() {
        boolean tour = true;
        while (p1.getPv() > 0 && p2.getPv() > 0) {
            if (tour) {
                selectAttaque(p1);
            } else {
                selectAttaque(p2);
            }
            tour = !tour;
        }
        return !tour;
    }

    private void selectAttaque(Player player, boolean alreadyCall) {
        var listAttaques = player.getAttaques();
        if (!alreadyCall) {
            System.out.println("[" + player.getName() + " ("+ player.getPv() +" PV) ] Choix d'attaque :");
            for (int i = 0; i < listAttaques.length; i++) {
                System.out.println(i + ")" + listAttaques[i].getName());
            }
        } else {
            System.out.println("Recommence .... avec un chiffre");
        }
        System.out.print("-> ");
        try {
            var select = sc.nextInt();
            player.attaque(select);
            System.out.println();
        } catch (InputMismatchException e) {
            sc = new Scanner(System.in);
            selectAttaque(player, true);
        } catch (ArrayIndexOutOfBoundsException e) {
            selectAttaque(player, true);
        }
    }

    private void selectAttaque(Player player) {
        selectAttaque(player, false);
    }

}
