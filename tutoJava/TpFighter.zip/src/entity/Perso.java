package entity;

public abstract class Perso {

    private String name;
    private int pv;

    Perso(String name, int pv) {
        this.name = name;
        this.pv = pv;
    }

    public int getPv() {
        return pv;
    }

    protected void setPv(int pv) {
        this.pv = pv;
    }

    public String getName() {
        return name;
    }
}
