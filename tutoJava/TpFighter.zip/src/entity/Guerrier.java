package entity;

public class Guerrier extends Player {
    public Guerrier() {
        super("Aragorn", 100);
        setAttaques(new Combo[] {
                new Combo("Coup d'épée", 10),
                new Combo("Charge", 7)
        });
    }
}
