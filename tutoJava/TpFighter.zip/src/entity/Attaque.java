package entity;

public interface Attaque {

    public void attaque(int select);

}
