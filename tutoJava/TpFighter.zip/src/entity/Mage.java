package entity;

public class Mage extends Player {
    public Mage() {
        super("Gandalf", 150);
        setAttaques(new Combo[] {
                new Combo("Coup bâton", 10),
                new Combo("Puy de lumière", 7)
        });
    }
}
