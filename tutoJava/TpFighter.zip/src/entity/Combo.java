package entity;

public class Combo {

    private String name;
    private int dommage;

    Combo(String name, int dommage) {
        this.name = name;
        this.dommage = dommage;
    }

    public String getName() {
        return name;
    }

    public int getDommage() {
        return dommage;
    }
}
