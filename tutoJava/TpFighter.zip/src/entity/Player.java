package entity;

public abstract class Player extends Perso implements Attaque {

    private Combo[] attaques;
    private Player ennemie;

    public Player(String name, int pv) {
        super(name, pv);
    }


    protected void setAttaques(Combo[] attaques) {
        this.attaques = attaques;
    }

    public Combo[] getAttaques() {
        return attaques;
    }

    public void setEnnemie(Player ennemie) {
        this.ennemie = ennemie;
    }

    private void getDommage(int dommage) {
        setPv(getPv() - dommage);
    }

    @Override
    public void attaque(int select) throws ArrayIndexOutOfBoundsException {
        System.out.println(getName() + " attaque : " + attaques[select].getName());
        ennemie.getDommage(attaques[select].getDommage());
    }
}
