import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent {
  @Input()
  title: string;
  @Input()
  content: string;
  @Input()
  comments: Array<any>;
  @Input()
  index: number

  constructor() {
    this.title = 'Default title';
    this.content = 'Default content';
    this.comments = []
    this.index = 0
  }
}
